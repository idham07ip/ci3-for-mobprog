<?php

class UserDTO {
    public $email;
    public $password;
}